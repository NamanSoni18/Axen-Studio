import frame_2947 from './Frame 2947.png';
import frame_2971 from './Frame 2971.png';
import frame_3054 from './Frame 3054.png';
import frame_3068 from './Frame 3068.png';
import frame_3069 from './Frame 3069.png';
import frame_3054_3 from './Frame 3054_3.png';
import frame_3069_3 from './Frame 3069_3.png';
import frame_3070_3 from './Frame 3070_3.png';
import frame_3054_4_1 from './Frame 3054_4_1.png';
import frame_3068_4_2 from './Frame 3068_4_2.png';
import frame_3069_4_3 from './Frame 3069_4_3.png';
import frame_3054_5_1 from './Frame 3054_5_1.png';
import frame_3069_5_2 from './Frame 3069_5_2.png';
import frame_3070_5_3 from './Frame 3070_5_3.png';


export const services_assets = {
  frame_2947,
  frame_2971,
  frame_3054,
  frame_3068,
  frame_3069,
  frame_3054_3,
  frame_3069_3,
  frame_3070_3,
  frame_3054_4_1,
  frame_3068_4_2,
  frame_3069_4_3,
  frame_3054_5_1,
  frame_3069_5_2,
  frame_3070_5_3,
};
