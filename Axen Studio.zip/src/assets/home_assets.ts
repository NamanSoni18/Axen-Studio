import home_img1 from "./home_img1.png";
import home_img2 from './home_img2.png';
import home_img3 from './home_img3.png';
import home_img4 from './home_img4.png';
import facebook from './facebook_.png';
import linkedin from './linkedin_.png';
import instagram from './instagram.png';
import section2 from './Section2.png';
import section3 from './Section3.png';
import section4_img1 from './section4_img1.png';
import section4_img2 from './section4_img2.png';
import section4_img3 from './section4_img3.png';
import section4_img4 from './section4_img4.png';
import vector from './Vector.svg';
import mail from './Frame 2889.svg';
import section5_img1 from './Section5_img1.png';
import section5_img2 from './Section5_img.png';
import section5_circle from './section5_circleImg.png';
import section5_rating from './Frame 2738.png';
import section6_review from './review_img1.png';
import section7_phone from './section7_phone.svg';
import section7_map from './section7_map.svg';
import section7_clock from './section7_clock.svg';
import section8_img1 from './Section8_team_img1.png';
import section9_img1 from './section9_img1.png';
import aboutus_section1_img1 from './About_section1_img1.png';


export const home_assets = {
  home_img1,
  home_img2,
  home_img3,
  home_img4,
  facebook,
  linkedin,
  instagram,
  section2,
  section3,
  section4_img1,
  section4_img2,
  section4_img3,
  section4_img4,
  vector,
  mail,
  section5_img1,
  section5_img2,
  section5_circle,
  section5_rating,
  section6_review,
  section7_phone,
  section7_map,
  section7_clock,
  section8_img1,
  section9_img1,
  aboutus_section1_img1
}