import Hero_Projects from './Hero'
import LatestProject from './LatestProject'
import OurProjects from './OurProjects'
import Footer from '../Footer/Footer'

const Projects = () => {
  return (
    <div>
      <Hero_Projects/>
      <LatestProject/>
      <OurProjects/>
      <Footer/>
    </div>
  )
}

export default Projects
