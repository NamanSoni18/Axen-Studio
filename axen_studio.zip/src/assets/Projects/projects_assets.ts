import hero_img1 from "./hero_img1.png";
import hero_img2 from "./hero_img2.png";
import latest_project_img1 from "./LatestProject_img1.png";
import section2_vector from './section2_vector.svg';
import section2_img2 from './section2_img2.png'
import OurProjects_img1 from './OurProjects_img1.png'
import OurProjects_img2 from './OurProjects_img2.png'
import OurProjects_img3 from './OurProjects_img3.png'
import OurProjects_img4 from './OurProjects_img4.png'
import OurProjects_img5 from './OurProjects_img5.png'
import OurProjects_img6 from './OurProjects_img6.png'
import OurProjects_img7 from './OurProjects_img7.png'
import OurProjects_img8 from './OurProjects_img8.png'
import OurProjects_img9 from './OurProjects_img9.png'
import OurProjects_img10 from './OurProjects_img10.png'
import OurProjects_img11 from './OurProjects_img11.png'


export const projects_assets = {
  hero_img1,
  hero_img2,
  latest_project_img1,
  section2_vector,
  section2_img2,
  OurProjects_img1,
  OurProjects_img2,
  OurProjects_img3,
  OurProjects_img4,
  OurProjects_img5,
  OurProjects_img6,
  OurProjects_img7,
  OurProjects_img8,
  OurProjects_img9,
  OurProjects_img10,
  OurProjects_img11
};
