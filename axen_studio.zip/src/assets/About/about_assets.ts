import hero_img1 from './Hero_img1.png'
import hero_img2 from './Hero_img2.png'
import Frame_3089 from './Frame 3089.png'
import Vector_left_arrow from './Vector_left_arrow.svg';
import Vector_right_arrow from './Vector_right_arrow.svg';
import Our_Studio from './Our Studio.png'
import OurTeam1 from './OurTeam1.png'
import Our_Studio_2 from './Our Studio_2.png';
import Our_Studio_3 from './Our Studio_3.png';
import Our_Studio_4 from './Our Studio_4.png';
import frame_3082 from './Frame 3082.png'
import vector from './Vector.svg'

export const about_assets = {
  hero_img1,
  hero_img2,
  Frame_3089,
  Vector_left_arrow,
  Vector_right_arrow,
  Our_Studio,
  OurTeam1,
  Our_Studio_2,
  Our_Studio_3,
  Our_Studio_4,
  frame_3082,
  vector
}