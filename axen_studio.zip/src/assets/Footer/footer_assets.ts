import footer_img1 from './footer_img1.png'

export const footer_assets = {
  footer_img1,
}